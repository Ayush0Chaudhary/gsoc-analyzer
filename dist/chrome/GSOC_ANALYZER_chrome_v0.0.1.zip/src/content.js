// // const targetSelector = 'body > app-root > app-layout > mat-sidenav-container > mat-sidenav-content.mat-drawer-content.mat-sidenav-content.site__main.theme.theme--gray.ng-star-inserted > div > div > main > app-program-organization > app-org-page-title > app-feature-banner > section > div > div > app-feature-cta > div';

// // DOMContentLoaded run this script
// document.addEventListener('DOMContentLoaded', function() {
//     const targetSelector = 'body > app-root'
//     const targetElement = document.getElementsByClassName('a');
//     console.log(targetElement);
//     if (targetElement) {
//       const buttonElement = document.createElement('button');
//       buttonElement.textContent = 'Click Me'; // Customize the button text
//       buttonElement.setAttribute('id', 'myCustomButton'); // Add an optional ID
    
//       // Add event listeners (optional)
//       buttonElement.addEventListener('click', () => {
//         console.log('Button clicked!');
//       });
//       console.log("kkkkkihuyguyggh");
//       console.log(buttonElement);
//       targetElement.appendChild(buttonElement);
//     } else {
//       console.log('Target element not found');
//     }
// });

// const data = require('./data.json');
// console.log(data);
console.log("bithch");